
function checkPass() {
  const input = document.getElementById("passInput").value.trim().toUpperCase();
  if (input === "TREASURESTAR") {
    document.getElementById("locked").style.display = "none";
    document.getElementById("treasureBox").classList.remove("hidden");
  } else {
    alert("Oops! That’s not it. Try again, bro!");
  }
}

let count = 10;
const countdownEl = document.getElementById("countdown");
const countdown = setInterval(() => {
  count--;
  countdownEl.innerText = count;
  if (count <= 0) {
    clearInterval(countdown);
    document.querySelector(".intro").style.display = "none";
    document.getElementById("locked").style.display = "block";
  }
}, 1000);
